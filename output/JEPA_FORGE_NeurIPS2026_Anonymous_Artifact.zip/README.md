# Anonymous JEPA-FORGE experiment artifact

This archive accompanies an author-review workshop draft. It is not evidence
of submission or acceptance. The historical study contains 273 MPS runs on
23 datasets. The new extension has 27 tasks on 25 underlying datasets, three
repeated splits, and 1,044 neural training trajectories. A separate transfer
study evaluates official frozen I-JEPA/V-JEPA models on two image subsets and
one synthetic-video task, plus 81 scratch training trajectories. Official
pretraining compute is not matched to the small scratch models.

## Verify the frozen evidence without GPU retraining

Use Python 3.11 or later from this directory:

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install '.[dev,report]'
PYTHONPATH=src python paper/neurips2026/build_evidence.py
PYTHONPATH=src python paper/neurips2026/build_extension_evidence.py
```

The builder verifies the frozen result hash against the saved validation report,
checks payload consistency, and derives all manuscript figures and tables.
This check does not replay absent checkpoints. Reports include the historical
results/selection_validation.json and the new extension/transfer validation
reports. The original 169-test report and current expanded test report are
separately labeled. Saved reports are recorded evidence, not
a claim that those checks have just been rerun on another machine.

## Rerun the full study

The supplied configuration requires an Apple MPS GPU with fallback disabled.
It fails explicitly if the required accelerator is unavailable. To use CUDA,
change the device explicitly and label the new run; do not equate it with the
frozen MPS measurement. Public datasets are downloaded into a local cache and
the synthetic cases are generated from the supplied code. Source provenance,
licenses, grouping qualifications, and transformations are documented in docs/.

Install the experiments extra for new comparisons and use fresh output directories:

```sh
python -m pip install '.[experiments]'
PYTHONPATH=src python scripts/run_extension.py \
  --output artifacts/new_extension
PYTHONPATH=src python scripts/validate_extension.py \
  --directory artifacts/new_extension
PYTHONPATH=src python scripts/run_vision_transfer.py \
  --output artifacts/new_vision
PYTHONPATH=src python scripts/validate_extension.py \
  --directory artifacts/new_vision --vision
PYTHONPATH=src python scripts/run_tests_private.py \
  --output artifacts/reproduction_tests.xml
```

These commands preserve the supplied frozen files in results/. The validation
script uses checkpoints and arrays produced by the new run. Exact historical
checkpoint bytes are not included and must not be claimed to have been verified
from this lightweight archive. The environment lock records the measured
development environment, while pyproject.toml specifies dependency ranges.
Some public-data tests require caches produced by the downloads and otherwise skip.
There is no promise of bitwise reproduction on different software or hardware.

## Scope and privacy

Included: source, tests, configurations, development security scripts, measured
compressed selection results, saved validation/test reports, manuscript source,
and result-derived tables/figures. Excluded: Git history, identities, credentials,
private proposal material, downloaded raw archives, and large model checkpoints.
No funding, institutional ethics approval, or public release is implied.

MANIFEST.json lists SHA-256 hashes for every other file in this archive. These
hashes establish internal byte integrity, not authenticity of the data sources.
The Apache-2.0 code license and synthetic/public data qualifications are supplied in
LICENSE and docs/. AI assistance is disclosed in the paper; human authors remain
responsible for the scientific content and any eventual submission.
