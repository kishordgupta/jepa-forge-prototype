# Anonymous workshop paper source

JEPA-FORGE: Auditable Context-Target Selection for Predictive Representations

This is an author-review draft, not a submission or acceptance notice.
Import this ZIP into Overleaf. Set the main document to main.tex and compiler
to XeLaTeX. Alternatively run `latexmk -xelatex main.tex` or `tectonic main.tex`.
Figures and tables are already supplied; no Python or GPU is needed to compile.

The source has explicit Anonymous Authors and empty author PDF metadata.
The workshop style comes from the official NeurIPS 2026 kit; two public email
identifiers were removed from comments only. Executable style lines are unchanged.
The `nonanonymous` option displays our explicit anonymous author line rather than
unfilled affiliation placeholders. Preserve anonymity for double-blind review.

Before submission, human authors must review all claims, citations, AI-use
disclosure, authorship, and current workshop requirements. Remove the explicitly
marked draft-footer override only when preparing an actual submission.

The separate anonymous evidence archive includes code, measured results,
data attribution, and regeneration instructions. No checkpoint collection or
private repository history is included here.
